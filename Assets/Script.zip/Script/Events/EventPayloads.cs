using System.Threading;
using UnityEngine;

//�C�x���g�Ŏg�p����l�B
public readonly struct HpInfo
{
    public readonly int Current;
    public readonly int Max;
    public HpInfo(int current, int max) { Current = current;Max = max;  }
}

public readonly struct DamageInfo
{
    public readonly float Accumulated;      //�݌v�_���[�W�B
    public readonly float Multiplier;       //�{���B
    public readonly int Total;              //�ŏI�_���[�W�B
    public DamageInfo(float accumulated, float multiplier, int total)
    { Accumulated = accumulated;Multiplier = multiplier;Total = total; }
}

public readonly struct EnemyMovedInfo
{
    public readonly Enemy Enemy;
    public readonly int FromCell;
    public readonly int ToCell;
    public EnemyMovedInfo(Enemy enemy,int from,int to)
    { Enemy = enemy;FromCell = from;ToCell = to; }
}