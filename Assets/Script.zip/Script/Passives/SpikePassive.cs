using System.Reflection;
using UnityEngine;

//�X�p�C�N:�ʏ�y�O�ɒǉ��U���B
[CreateAssetMenu(fileName ="SpikePassive",menuName ="Game/Passive/Spike")]
public class SpikePassive:PassiveEffect
{
    public override int ModifyNormalPegDamage(int baseDamage)
    {
        return baseDamage + GameConstants.SpikeBonus;
    }
}
