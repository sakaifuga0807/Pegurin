using UnityEngine;
using System.Collections.Generic;

public class PegBoard : MonoBehaviour
{
    private List<Peg> allPegs = new List<Peg>();

    private void Awake()
    {
        Peg[] foundPegs = GetComponentsInChildren<Peg>(true);
        allPegs = new List<Peg>(foundPegs);
    }

    /// <summary>
    /// �Ֆʂ̃y�O��S����������
    /// </summary>
    public void RefreshAllPegs()
    {
        foreach (var peg in allPegs)
        {
            if (peg != null)
            {
                peg.ResetPegState();
            }
        }
    }

    //�L���ȃy�O�̐��B
    public int ActivePegCount
    {
        get
        {
            int count = 0;
            foreach (var peg in allPegs)
            {
                if (peg != null && peg.gameObject.activeSelf) count++;
            }
            return allPegs.Count;
        }
    }

    //�Ֆʂ̃y�O��0���̎������S����������B
    public void RestoreAllIfEmpty()
    {
        if(ActivePegCount==0)
        {
            RefreshAllPegs();
        }
    }

    private void Start()
    {
        var context = BattleContext.Current;
        if(context!=null&&context.RunManager!=null)
        {
            context.RunManager.OnStageStarted += HandleStageStarted;
        }
    }

    private void OnDestroy()
    {
        var context = BattleContext.Current;
        if(context!=null&&context.RunManager!=null)
        {
            context.RunManager.OnStageStarted -= HandleStageStarted;
        }
    }

    //�X�e�[�W�J�n���Ƀy�O��S����������B
    private void HandleStageStarted(int stageIndex,StageConfig stage)
    {
        RefreshAllPegs();
    }
}