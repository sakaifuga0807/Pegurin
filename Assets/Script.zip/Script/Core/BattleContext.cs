using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

//�V�[�����̎�v�Q�Ƃ��܂Ƃ߂Ă����R���e�i�B(�V���O���g���ɂ͂����ɃV�[���Ɉ����)
public class BattleContext : MonoBehaviour
{
    public static BattleContext Current { get; private set; }
    public DamageCalculator DamageCalculator { get; private set; }
    public EnemyLane EnemyLane { get; private set; }

    [field: SerializeField] public PegBoard PegBoard { get; private set; }
    [field: SerializeField] public DeckManager DeckManager { get; private set; }
    [field: SerializeField] public PassiveManager PassiveManager { get; private set; }
    [field: SerializeField] public BattleStateMachine BattleStateMachine { get; private set; }
    [field: SerializeField] public Player Player { get; private set; }
    [field: SerializeField] public RunManager RunManager { get; private set; }
    [field: SerializeField] public SoundPlayer SoundPlayer { get; private set; }

    private void Awake()
    {
        Current = this;
        DamageCalculator = new DamageCalculator();
        EnemyLane = new EnemyLane();
    }

    private void OnDestroy()
    {
        if(Current==this)
        {
            Current = null;
        }
    }
}
