using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//BGM�̎�ށB�X�e�[�W1~3�͓���BGM�𑱂��ė����B
public enum BgmCue { Title,Battle,Boss}

//Bgm�̈�s�Ԃ�B
[System.Serializable]
public class BgmEntry
{
    public BgmCue cue;
    public AudioClip clip;
    [Range(0f, 1f)] public float volume = 0.6f;
}

//Bgm��炷�BRunManager�̃C�x���g���󂯂ď�ʂɂ���ċȂ�؂�ւ���B
public class BgmPlayer:MonoBehaviour
{
    [SerializeField] private RunManager runManager;

    [Header("Bgm�̊��蓖��")]
    [SerializeField] private List<BgmEntry> entries = new List<BgmEntry>();

    [Header("�Đ��ݒ�")]
    [Range(0f, 1f)]
    [SerializeField] private float masterVolume = 1f;
    [Tooltip("�Ȃ̐؂�ւ��ɏ����鐔�b")]
    [SerializeField] private float fadeSeconds = 1f;
    [Tooltip("�{�X���Bgm")]
    [SerializeField] private float bossDelaySeconds = 6.5f;

    [Header("�m�F�p")]
    [SerializeField] private bool logPlays = false;

    private AudioSource source;
    private BgmCue? currentCue;
    private Coroutine routine;

    private void Awake()
    {
        source = gameObject.AddComponent<AudioSource>();
        source.playOnAwake = false;
        source.loop = true;
        source.spatialBlend = 0f;
        source.volume = 0f;
    }

    private void Start()
    {
        if(runManager==null)
        {
            Debug.LogWarning("BgmPlayer��RunManager�����ݒ�ł�");
            return;
        }

        runManager.OnStageStarted += HandleStageStarted;
        runManager.OnRunCleared += HandleStop;
        runManager.OnRunGameOver += HandleStop;
        runManager.OnReturnedToTitle += HandleTitle;

        //RunManager��Start����ɓ������ꍇ�̎�肱�ڂ���h���B
        ApplyCurrentState();
    }

    private void OnDestroy()
    {
        if(runManager==null)
        {
            return;
        }

        runManager.OnStageStarted -= HandleStageStarted;
        runManager.OnRunCleared -= HandleStop;
        runManager.OnRunGameOver -= HandleStop;
        runManager.OnReturnedToTitle -= HandleTitle;
    }

    private void ApplyCurrentState()
    {
        switch (runManager.Phase)
        {
            case RunPhase.Title:
                Play(BgmCue.Title);
                break;
            case RunPhase.Battle:
            case RunPhase.Reward:
            case RunPhase.Map:
                HandleStageStarted(runManager.StageIndex, runManager.CurrentStage);
                break;
        }
    }

    private void HandleStageStarted(int stageIndex,StageConfig stage)
    {
        bool boss = stage != null && stage.isBoss;
        Play(boss ? BgmCue.Boss : BgmCue.Battle, boss ? bossDelaySeconds : 0f);
    }

    private void HandleTitle() { Play(BgmCue.Title); }
    private void HandleStop() { Stop(); }

    //�Ȃ�؂�ւ���B���Ɠ����Ȃ牽�����Ȃ��B
    public void Play(BgmCue cue,float delay=0f)
    {
        if(currentCue==cue)
        {
            return;
        }

        currentCue = cue;

        BgmEntry entry = entries.Find(e => e.cue == cue);
        if(logPlays)
        {
            Debug.Log($"[BGM]{cue}{(entry != null && entry.clip != null ? entry.clip.name : "(�ȂȂ�)")}");
        }
        StartFade(entry != null ? entry.clip : null, entry != null ? entry.volume : 0f, delay);
    }

    //BGM���~�߂�(�t�F�[�h�A�E�g)
    public void Stop()
    {
        currentCue = null;
        if(logPlays)
        {
            Debug.Log("[BGM]��~");
        }
        StartFade(null, 0f, 0f);
    }

    private void StartFade(AudioClip clip, float volume, float delay)
    {
        if (routine != null)
        {
            StopCoroutine(routine);
        }
        routine = StartCoroutine(FadeRoutine(clip, volume * masterVolume, delay));
    }

    private IEnumerator FadeRoutine(AudioClip clip,float targetVolume,float delay)
    {
        //���̋Ȃ��t�F�[�h�A�E�g����B
        if(source.isPlaying)
        {
            yield return FadeTo(0f);
            source.Stop();
        }

        //�W���O���Ȃǂ̂��߂ɒx�点��B
        float wait = delay - fadeSeconds;
        if (wait > 0f) yield return new WaitForSeconds(wait);

        if (clip == null) yield break;

        source.clip = clip;
        source.volume = 0f;
        source.Play();
        yield return FadeTo(targetVolume);
    }
    
    private IEnumerator FadeTo(float target)
    {
        float start = source.volume;
        float time = 0f;
        float duration = Mathf.Max(0f, fadeSeconds);
        while(time<duration)
        {
            time += Time.unscaledDeltaTime;
            source.volume = Mathf.Lerp(start, target, Mathf.Clamp01(time / duration));
            yield return null;
        }
        source.volume = target;
    }
}