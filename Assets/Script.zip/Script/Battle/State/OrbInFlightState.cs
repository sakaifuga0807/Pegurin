using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrbInFlightState : IBattleState
{
    public void Enter(BattleStateMachine stateMachine)
    {
        Debug.Log("�ʂ����ł��[");
    }
}

