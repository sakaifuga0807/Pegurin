using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInputState:IBattleState
{
    public void Enter(BattleStateMachine stateMachine)
    {
        Debug.Log("���͑҂��A�A���˂��ā[");
    }
}
